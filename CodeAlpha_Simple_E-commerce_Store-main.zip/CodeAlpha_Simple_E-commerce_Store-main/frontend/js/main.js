document.getElementById("adminBtn").addEventListener("click", () => {
    window.location.href = "admin-login.html";
  });
  
  document.getElementById("userBtn").addEventListener("click", () => {
    window.location.href = "user-login.html";
  });
  